# How to

0. Get your `input` file and place it in root folder
1. Install dependencies: `npm i`
2. Bundle solution: `./node_modules/rollup/bin/rollup -c`
3. Find optimal bits/hashes number: `node find_optimal_filter.js`
4. Generate required dataset: `node generate.js <bits> <hashes>`
5. Test it: `node test.js . ./seeds`
6. ???
7. PROFIT!
